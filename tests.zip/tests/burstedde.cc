#include "../benchmarks/burstedde/burstedde.cc"
