#include "../benchmarks/solkz/solkz.cc"

