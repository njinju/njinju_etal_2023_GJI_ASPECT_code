#include "composition_active_with_melt.cc"
