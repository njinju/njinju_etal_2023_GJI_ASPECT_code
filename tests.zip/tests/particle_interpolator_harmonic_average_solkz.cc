#include "../benchmarks/solkz/compositional_fields/solkz_compositional_fields.cc"

