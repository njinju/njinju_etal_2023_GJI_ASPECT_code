#include "../benchmarks/entropy_adiabat/plugins/compute_entropy_profile.cc"
#include "../benchmarks/entropy_adiabat/plugins/entropy_advection.cc"
#include "../benchmarks/entropy_adiabat/plugins/entropy_model.cc"
