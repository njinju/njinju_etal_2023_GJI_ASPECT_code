#include "../benchmarks/solcx/compositional_fields/solcx_compositional_fields.cc"
