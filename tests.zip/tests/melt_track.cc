#include <../benchmarks/solitary_wave/solitary_wave.cc>
