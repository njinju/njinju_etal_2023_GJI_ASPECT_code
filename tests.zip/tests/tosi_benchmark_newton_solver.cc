#include <../benchmarks/tosi_et_al_2015_gcubed/tosi.cc>
