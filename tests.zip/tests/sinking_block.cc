#include "../benchmarks/sinking_block/sinking_block.cc"
