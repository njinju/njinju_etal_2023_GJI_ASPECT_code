#include "rising_melt_blob.cc"
