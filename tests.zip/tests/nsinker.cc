#include "../benchmarks/nsinker/nsinker.cc"
