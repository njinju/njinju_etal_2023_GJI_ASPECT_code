#include <../benchmarks/shear_bands/shear_bands.cc>
