#include "../benchmarks/king2dcompressible/code.cc"
