#include <../benchmarks/rigid_shear/plugin/rigid_shear.cc>
