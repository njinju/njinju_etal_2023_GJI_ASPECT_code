The files in this directory can be used to recreate the Tosi et al. (2015)
benchmark figures from the Fraters, Bangerth, Thieulot, Glerum and Spakman
(G-Cubed, submitted, 2018) paper. Adjust both the metabash.sh and bash.sh files
to reflect the parameter search you are interested in and run the metabash
script. If you have run exactly the same runs as shown in the paper, you can
use the gnuplot files in plotfiles to recreate the figures in that paper. This
bechmark requires the shared library from the benchmarks/tosi_et_al_2015_gcubed
folder in the ASPECT repository. 
